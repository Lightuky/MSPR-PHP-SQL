<?php

require_once '../includes/helpers.php';

$pending = isset($_GET['s']) ? $_GET['s'] : null;
$user_id = isset($_GET['id']) ? $_GET['id'] : null;

session_start();

if ($pending = 0) {
    addFriend($pending, $_SESSION['auth_id'], $user_id);
}
elseif ($pending = 1) {
    acceptFriendRequest($pending, $_SESSION['auth_id'], $user_id);
}
elseif ($pending = 2) {
    deleteFriend($pending, $_SESSION['auth_id'], $user_id);
}
