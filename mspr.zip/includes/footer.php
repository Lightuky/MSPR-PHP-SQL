</main>

</div>
<script src="./public/js/manifest.js"></script>
<script src="./public/js/vendor.js"></script>
<script src="./public/js/app.js"></script>
</body>
</html>