<?php
use Carbon\Carbon;

Carbon::setLocale('fr');